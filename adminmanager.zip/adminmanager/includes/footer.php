<footer class="footer text-center">
 All Rights Reserved by Transaction. Developed by <a href="https://uptechng.com" target="blank">UPTECH</a>.
</footer>
           