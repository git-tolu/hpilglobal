<?php
$dnd = "2"; //6 or 'international' is for Sending to all Nigerian numbers via the International Route. This option can deliver to DND numbers with your preferred sender ID.
$apikey = "Trx4DZ39oftpIyxTZZ7l3osbHi9yJx6oNaTHmRjNP4J0PzkYPEKJbxJtygbm";	
?>