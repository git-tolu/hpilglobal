<footer class="footer text-center">
 All Rights Reserved by Experiential Marketers' Association Of Nigeria (EXMAN). Developed by <a href="https://uptechng.com" target="blank">UPTECH</a>.
</footer>
           