 <aside  class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <!-- User Profile-->
                       
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark" href="dashboard.php" aria-expanded="false"><i class="mdi mdi-view-dashboard"></i><span class="hide-menu">Dashboard </span></a>
                          
                        </li>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="mdi mdi-account-star"></i><span class="hide-menu">Membership </span></a>
                            <ul aria-expanded="false" class="collapse  first-level">
                                <li class="sidebar-item"><a href="pendingmembers.php" class="sidebar-link"><i class="mdi mdi-view-quilt"></i><span class="hide-menu">Pending Members </span></a></li>
                                <li class="sidebar-item"><a href="fullmembers.php" class="sidebar-link"><i class="mdi mdi-view-parallel"></i><span class="hide-menu"> Active Registered </span></a></li>
                              
                            </ul>
                        </li>
						
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="mdi mdi-wallet-membership"></i><span class="hide-menu">Annual Dues </span></a>
                            <ul aria-expanded="false" class="collapse  first-level">
                                <li class="sidebar-item"><a href="owingmembers.php" class="sidebar-link"><i class="mdi mdi-format-align-left"></i><span class="hide-menu"> Owing Members </span></a></li>
                                <li class="sidebar-item"><a href="paymenthistory.php" class="sidebar-link"><i class="mdi mdi-format-align-right"></i><span class="hide-menu"> Payment History </span></a></li>

                            </ul>
                        </li>
						
						
                      
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="awards.php" aria-expanded="false"><i class="mdi mdi-trophy-award"></i><span class="hide-menu">Manage Awards</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="bank.php" aria-expanded="false"><i class="mdi mdi-treasure-chest"></i><span class="hide-menu">Manage Bank</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="selectyear.php" aria-expanded="false"><i class="mdi mdi-account-convert"></i><span class="hide-menu">Manage BEX Summit</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="generalnotice.php" aria-expanded="false"><i class="mdi mdi-bell-ring"></i><span class="hide-menu">General Notification</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="logout.php" aria-expanded="false"><i class="mdi mdi mdi-power"></i><span class="hide-menu">Log Out</span></a></li>
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>