 <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-5 align-self-center">
                        <h4 class="page-title"><?php  ?></h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#"><?php echo $home; ?></a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php echo $page; ?></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-7 align-self-center">
                        <div class="d-flex no-block justify-content-end align-items-center">
                            
                            <div class="">
                                <h5 class="text-info m-b-0 font-medium"><?php echo $apptitle; ?></h5></div>
                        </div>
                    </div>
                </div>
            </div>