<?php
$dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '10Ade10@';
   $dbname = 'exmandb';
   $conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
?>